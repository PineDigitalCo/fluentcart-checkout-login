(function () {
	'use strict';

	function getInfo() {
		return window.fluentcart_checkout_info || {};
	}

	function toast(message, variant) {
		if (typeof Toastify !== 'function' || !message) {
			if (message) {
				window.alert(message);
			}
			return;
		}
		const bg =
			variant === 'success'
				? 'linear-gradient(to right, #00b09b, #96c93d)'
				: 'linear-gradient(to right, #ff8a23, #ffc051)';
		// eslint-disable-next-line no-new
		new Toastify({
			text: message,
			className: variant || 'info',
			duration: 3200,
			style: { background: bg, color: '#fff' },
		}).showToast();
	}

	document.addEventListener('DOMContentLoaded', function () {
		const form = document.querySelector('[data-fcl-checkout-login-form]');
		if (!form) {
			return;
		}

		const btn = form.querySelector('[data-fcl-checkout-login-submit]');
		const info = getInfo();
		const rest = info.rest || {};

		function loginEndpoint() {
			const base = (rest.url || '').replace(/\/$/, '');
			return base ? base + '/user/login' : '';
		}

		function clearErrors() {
			form.querySelectorAll('[data-fcl-checkout-login-error]').forEach(function (el) {
				el.textContent = '';
				const wrap = el.closest('[data-fcl-checkout-login-field-wrap]');
				if (wrap) {
					wrap.classList.remove('has-error');
				}
			});
		}

		function fieldError(forName, text) {
			const el = form.querySelector(
				'[data-fcl-checkout-login-error][data-fcl-field="' + forName + '"]',
			);
			if (el) {
				el.textContent = text;
				const wrap = el.closest('[data-fcl-checkout-login-field-wrap]');
				if (wrap) {
					wrap.classList.add('has-error');
				}
			} else {
				toast(text, 'warning');
			}
		}

		form.querySelectorAll('input').forEach(function (inp) {
			inp.addEventListener('input', function () {
				const wrapper = inp.closest('[data-fcl-checkout-login-field-wrap]');
				if (!wrapper || !inp.name) {
					return;
				}
				wrapper.classList.remove('has-error');
				const err = form.querySelector(
					'[data-fcl-checkout-login-error][data-fcl-field="' + inp.name + '"]',
				);
				if (err) {
					err.textContent = '';
				}
			});
		});

		form.addEventListener('submit', function (e) {
			e.preventDefault();

			clearErrors();

			let userLogin = (form.querySelector('[name="user_login"]') || {}).value;
			userLogin = typeof userLogin === 'string' ? userLogin.trim() : '';
			const password = (form.querySelector('[name="password"]') || {}).value || '';
			const remember = form.querySelector('[name="remember_me"]:checked');

			if (!userLogin) {
				fieldError(
					'user_login',
					window.fluentcart &&
						window.fluentcart.$t &&
						window.fluentcart.$t('Username or Email is required')
						? window.fluentcart.$t('Username or Email is required')
						: 'Username or email is required.',
				);
				return;
			}
			if (!password) {
				fieldError(
					'password',
					window.fluentcart &&
						window.fluentcart.$t &&
						window.fluentcart.$t('Password is required')
						? window.fluentcart.$t('Password is required')
						: 'Password is required.',
				);
				return;
			}

			const url = loginEndpoint();
			const nonce = rest.nonce;
			if (!url || !nonce) {
				toast('Checkout data is unavailable. Please refresh this page.', 'warning');
				return;
			}

			const body = new URLSearchParams({
				user_login: userLogin,
				password: password,
				remember_me: remember ? 'on' : '',
			});

			let originalLabel = '';
			if (btn) {
				btn.disabled = true;
				originalLabel = btn.textContent;
				btn.setAttribute('data-fcl-label-saved', originalLabel);
				btn.textContent =
					btn.getAttribute('data-fcl-submitting-label') ||
					(window.fluentcart && window.fluentcart.$t
						? window.fluentcart.$t('Please wait...')
						: 'Please wait…');
			}

			const xhr = new XMLHttpRequest();
			xhr.open('POST', url, true);
			xhr.setRequestHeader(
				'Content-Type',
				'application/x-www-form-urlencoded; charset=UTF-8',
			);
			xhr.setRequestHeader('X-WP-Nonce', nonce);

			xhr.onload = function () {
				let payload = null;
				try {
					payload = JSON.parse(xhr.responseText);
				} catch (_ignore) {
					payload = null;
				}

				const okHttp = xhr.status >= 200 && xhr.status < 300;
				const success = !!(payload && payload.success);

				if (okHttp && success) {
					toast((payload.data && payload.data.message) || 'Logged in.', 'success');
					window.location.reload();
					return;
				}

				if (btn) {
					btn.disabled = false;
					btn.textContent = btn.getAttribute('data-fcl-label-saved') || originalLabel;
				}

				const errMsg =
					(payload && payload.data && (payload.data.message || payload.message)) ||
					payload.message ||
					(window.fluentcart && window.fluentcart.$t
						? window.fluentcart.$t('Login failed. Please try again.')
						: 'Login failed. Please try again.');
				toast(errMsg, 'warning');
			};

			xhr.onerror = function () {
				if (btn) {
					btn.disabled = false;
					btn.textContent =
						btn.getAttribute('data-fcl-label-saved') || originalLabel;
				}
				toast(
					window.fluentcart && window.fluentcart.$t
						? window.fluentcart.$t('Network error occurred')
						: 'Network error.',
					'warning',
				);
			};

			xhr.send(body.toString());
		});
	});
})();
