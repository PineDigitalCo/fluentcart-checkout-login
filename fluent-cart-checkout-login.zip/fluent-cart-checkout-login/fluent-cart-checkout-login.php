<?php
/**
 * Plugin Name: FluentCart Checkout Login
 * Description: Lets guests log in from the FluentCart checkout page and stay on checkout after signing in (reuses FluentCart’s REST login).
 * Version: 1.0.3
 * Author: My Listing Pro
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPLv2 or later
 * Text Domain: fluent-cart-checkout-login
 *
 * @package FluentCartCheckoutLogin
 */

declare(strict_types=1);

defined('ABSPATH') || exit;

define('FCL_CHK_LOGIN_VERSION', '1.0.3');
define('FCL_CHK_LOGIN_FILE', __FILE__);

final class FluentCart_Checkout_Login {

	private static bool $assets_enqueued = false;

	public static function init(): void {
		add_action('plugins_loaded', [self::class, 'hooks']);
	}

	public static function hooks(): void {
		if (!defined('FLUENTCART_PLUGIN_PATH')) {
			add_action('admin_notices', [self::class, 'admin_notice_missing_fluentcart']);
			return;
		}

		add_action('fluent_cart/after_checkout_page_start', [self::class, 'maybe_enqueue_assets'], 5);
		// Render before the [data-fluent-cart-checkout-page] wrapper so login markup is not inside FluentCart’s checkout root (avoids DOM collisions with checkout JS).
		add_action('fluent_cart/before_checkout_page_start', [self::class, 'render_login_panel'], 5);
	}

	public static function admin_notice_missing_fluentcart(): void {
		if (!current_user_can('activate_plugins')) {
			return;
		}

		echo '<div class="notice notice-warning"><p>';
		esc_html_e(
			'FluentCart Checkout Login is inactive until FluentCart is installed and activated.',
			'fluent-cart-checkout-login',
		);
		echo '</p></div>';
	}

	public static function maybe_enqueue_assets(array $hook_data): void {
		unset($hook_data);

		if (self::$assets_enqueued || is_user_logged_in()) {
			return;
		}

		if (false === apply_filters('fcl/checkout_login/enabled', true)) {
			return;
		}

		self::$assets_enqueued = true;

		wp_enqueue_style(
			'fcl-checkout-login',
			plugins_url('assets/checkout-login.css', FCL_CHK_LOGIN_FILE),
			[],
			FCL_CHK_LOGIN_VERSION,
		);

		wp_enqueue_script(
			'fcl-checkout-login',
			plugins_url('assets/checkout-login.js', FCL_CHK_LOGIN_FILE),
			['fct-checkout'],
			FCL_CHK_LOGIN_VERSION,
			true,
		);
	}

	public static function render_login_panel(array $hook_data): void {
		unset($hook_data);

		if (is_user_logged_in()) {
			return;
		}

		if (false === apply_filters('fcl/checkout_login/enabled', true)) {
			return;
		}

		$lost_source = home_url('/');
		if (function_exists('wp_get_current_url')) {
			$lost_source = wp_get_current_url();
		}

		$lost_redirect = wp_validate_redirect(
			wp_sanitize_redirect($lost_source),
			home_url('/'),
		);
		$lost_url = wp_lostpassword_url($lost_redirect);
		?>
<section
	class="fcl-checkout-login fcl-checkout-login-panel"
	data-fcl-checkout-login-panel
	aria-label="<?php esc_attr_e('Returning customer login', 'fluent-cart-checkout-login'); ?>"
>
	<h3 class="fcl-checkout-login__title"><?php esc_html_e('Already have an account?', 'fluent-cart-checkout-login'); ?></h3>
	<p class="fcl-checkout-login__intro">
		<?php esc_html_e('Log in to reuse your billing details where available.', 'fluent-cart-checkout-login'); ?>
	</p>
	<form
		class="fcl-checkout-login__form"
		data-fcl-checkout-login-form
		method="post"
		action="#"
		autocomplete="on"
	>
		<div
			class="fcl-checkout-login__section"
			role="group"
			aria-labelledby="fcl-checkout-login-fields-label"
		>
			<div class="fcl-checkout-login__section-body">
				<h4 id="fcl-checkout-login-fields-label" class="sr-only">
					<?php esc_html_e('Login credentials', 'fluent-cart-checkout-login'); ?>
				</h4>

				<div class="fcl-checkout-login__field" data-fcl-checkout-login-field-wrap>
					<label class="fcl-checkout-login__label" for="fcl-login-user_login">
						<span class="fcl-checkout-login__label-text"><?php esc_html_e('Username or email address', 'fluent-cart-checkout-login'); ?> <abbr class="required" title="<?php esc_attr_e('required', 'fluent-cart-checkout-login'); ?>">*</abbr></span>
					</label>
					<input
						class="fcl-checkout-login__input"
						id="fcl-login-user_login"
						name="user_login"
						type="text"
						autocomplete="username"
						aria-required="true"
					/>
					<span class="fcl-checkout-login__error" role="alert" data-fcl-checkout-login-error data-fcl-field="user_login"></span>
				</div>

				<div
					class="fcl-checkout-login__field fcl-checkout-login__field--spaced"
					data-fcl-checkout-login-field-wrap
				>
					<label class="fcl-checkout-login__label" for="fcl-login-password">
						<span class="fcl-checkout-login__label-text"><?php esc_html_e('Password', 'fluent-cart-checkout-login'); ?> <abbr class="required" title="<?php esc_attr_e('required', 'fluent-cart-checkout-login'); ?>">*</abbr></span>
					</label>
					<input
						class="fcl-checkout-login__input"
						id="fcl-login-password"
						name="password"
						type="password"
						autocomplete="current-password"
						aria-required="true"
					/>
					<span class="fcl-checkout-login__error" role="alert" data-fcl-checkout-login-error data-fcl-field="password"></span>
				</div>

				<div class="fcl-checkout-login__remember-wrap">
					<input id="fcl-login-remember" type="checkbox" name="remember_me" value="on" />
					<label class="fcl-checkout-login__checkbox-label" for="fcl-login-remember">
						<?php esc_html_e('Remember me', 'fluent-cart-checkout-login'); ?>
					</label>
				</div>
			</div>
		</div>

		<div class="fcl-checkout-login__actions-row">
			<button
				type="submit"
				class="fcl-checkout-login__submit fcl-checkout-login__submit--primary"
				data-fcl-checkout-login-submit
				data-fcl-submitting-label="<?php echo esc_attr__('Please wait…', 'fluent-cart-checkout-login'); ?>"
			>
				<?php esc_html_e('Log in', 'fluent-cart-checkout-login'); ?>
			</button>
			<span class="fcl-checkout-login__lost">
				<a href="<?php echo esc_url($lost_url); ?>"><?php esc_html_e('Lost your password?', 'fluent-cart-checkout-login'); ?></a>
			</span>
		</div>
	</form>
</section>
		<?php
	}

}

FluentCart_Checkout_Login::init();
